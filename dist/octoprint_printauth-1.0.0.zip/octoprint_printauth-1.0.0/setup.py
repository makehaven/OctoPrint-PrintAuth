from setuptools import setup, find_packages

setup(
    name="OctoPrint-PrintAuth",
    version="1.0.0",
    packages=find_packages("src"),
    package_dir={"": "src"},
    install_requires=[
        "requests",
        "flask"
    ],
    entry_points={
        "octoprint.plugin": [
            "print_auth_plugin = octoprint_printauth.printauth:PrintAuthPlugin"
        ]
    },
    package_data={
        "octoprint_printauth": ["static/js/*", "static/css/*", "templates/*"]
    },
    include_package_data=True,
)
